js2me.createClass({
	package: 'javaRoot.$com.$samsung.$util',
	name: '$SM'
});
