js2me.createClass({
	/*
	 * int getStartX()
	 */
	$getStartX$$I: function () {
		return this.x;
	},
	/*
	 * int getStartY()
	 */
	$getStartY$$I: function () {
		return this.y;
	},
	/*
	 * int getType()
	 */
	$getType$$I: function () {
		return this.type;
	}
});

