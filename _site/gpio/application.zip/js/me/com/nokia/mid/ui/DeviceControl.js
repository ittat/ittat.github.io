js2me.createClass({
	/*
	 * public static void setLights(int num, int level)
	 */
	$setLights$II$V: function (num, level) {
		// Yeah, turning lights on!
	}
});

