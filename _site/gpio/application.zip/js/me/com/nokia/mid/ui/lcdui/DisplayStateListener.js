js2me.createInterface({});

