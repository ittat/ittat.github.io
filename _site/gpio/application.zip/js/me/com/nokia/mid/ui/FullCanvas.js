js2me.createClass({
	superClass: 'javaRoot.$javax.$microedition.$lcdui.$Canvas'
});

