js2me.createClass({
	$appendIndicator$Lcom_nokia_mid_ui_lcdui_Indicator_Z$I: function () {
	},
	$getIndicatorManager$$Lcom_nokia_mid_ui_lcdui_IndicatorManager_: function () {
		return new javaRoot.$com.$nokia.$mid.$ui.$lcdui.$IndicatorManager();
	}
});

