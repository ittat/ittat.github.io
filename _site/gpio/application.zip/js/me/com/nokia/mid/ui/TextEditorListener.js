js2me.createInterface({
});

