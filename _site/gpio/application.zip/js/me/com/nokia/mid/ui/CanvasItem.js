js2me.createClass({
	
});

