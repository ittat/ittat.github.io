js2me.createClass({
	
});
