js2me.createClass({
	_init$ILjavax_microedition_lcdui_Image_$V: function () {
	},
	$setActive$Z$V: function () {
	}
});

