js2me.createClass({
	_init$J$V: function (value) {
		this.value = value;
	},
	$longValue$$J: function () {
		return this.value;
	}
});
