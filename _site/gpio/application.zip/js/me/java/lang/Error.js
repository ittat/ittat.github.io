js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Throwable',
	package: 'javaRoot.$java.$lang',
	name: '$Error'
});

