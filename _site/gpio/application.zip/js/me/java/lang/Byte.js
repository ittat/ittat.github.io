js2me.createClass({
	/*
	 * public Byte(byte value)
	 */
	_init$B$V: function (value) {
		this.value = value;
	},
	$byteValue$$B: function () {
		return this.value;
	}
});
