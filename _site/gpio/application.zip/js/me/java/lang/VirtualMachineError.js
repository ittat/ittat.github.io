js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Error',
	package: 'javaRoot.$java.$lang',
	name: '$VirtualMachineError'
});

