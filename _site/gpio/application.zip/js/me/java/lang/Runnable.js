js2me.createInterface({
	name: '$Runnable',
	package: 'javaRoot.$java.$lang'
});
	

