js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Error'
});
