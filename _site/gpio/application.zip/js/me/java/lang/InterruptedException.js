js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Exception',
	name: '$InterruptedException',
	package: 'javaRoot.$java.$lang'
});
