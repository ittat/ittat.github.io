js2me.createClass({
	/*
	 * public WeakReference(Object referent)
	 */
	_init$Ljava_lang_Object_$V: function (referent) {
		this.referent = referent;
	},
	/*
	 * public Object get()
	 */
	$get$$Ljava_lang_Object_: function () {
		return this.referent;
	}
});
