js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$RuntimeException',
	name: '$ClassCastException',
	package: 'javaRoot.$java.$lang'
});
