js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$RuntimeException',
	name: '$NullPointerException',
	package: 'javaRoot.$java.$lang'
});
