js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$VirtualMachineError',
	package: 'javaRoot.$java.$lang',
	name: '$OutOfMemoryError'
});

