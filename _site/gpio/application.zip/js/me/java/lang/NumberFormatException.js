js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Exception'
});

