js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Exception',
	name: '$IndexOutOfBoundsException',
	package: 'javaRoot.$java.$lang'
});
	

