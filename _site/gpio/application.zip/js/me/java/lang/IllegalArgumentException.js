js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$RuntimeException',
	name: '$IllegalArgumentException',
	package: 'javaRoot.$java.$lang'
});
	

