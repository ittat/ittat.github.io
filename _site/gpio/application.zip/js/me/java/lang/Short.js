js2me.createClass({
	/*
	 * public Short(short value)
	 */
	_init$S$V: function (value) {
		this.value = value;
	},
	/*
	 * public int hashCode()
	 */
	$hashCode$$I: function () {
		return this.value;
	},
	/*
	 * public short shortValue()
	 */
	$shortValue$$S: function () {
		return this.value;
	}
});
