js2me.createClass({
	/*
	 * public Float(float value)
	 */
	_init$F$V: function (value) {
		this.value = value;
	}
});
