js2me.createClass({});

