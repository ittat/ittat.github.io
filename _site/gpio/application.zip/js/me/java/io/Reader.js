js2me.createClass({
	package: 'javaRoot.$java.$io',
	name: '$Reader'
});

