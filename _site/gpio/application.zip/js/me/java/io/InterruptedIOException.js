js2me.createClass({
	superClass: 'javaRoot.$java.$io.$IOException'
});
	

