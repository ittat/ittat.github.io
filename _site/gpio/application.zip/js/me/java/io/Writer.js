js2me.createClass({
});

