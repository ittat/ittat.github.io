js2me.createClass({
	superClass: 'javaRoot.$java.$io.$IOException',
	name: '$EOFException',
	package: 'javaRoot.$java.$io'
});
	

