js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$RuntimeException',
	name: '$NoSuchElementException',
	package: 'javaRoot.$java.$util'
});
