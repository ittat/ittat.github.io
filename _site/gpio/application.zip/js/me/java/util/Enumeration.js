js2me.createInterface({
});
