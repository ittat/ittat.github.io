js2me.createClass({
	construct: function () {
		this.date = new Date();
	},
	/*
	 * public static TimeZone getDefault()
	 */
	$getDefault$$Ljava_util_TimeZone_: function () {
		return new javaRoot.$java.$util.$TimeZone();
	},
	/*
	 * public static TimeZone getTimeZone(String ID)
	 */
	$getTimeZone$Ljava_lang_String_$Ljava_util_TimeZone_: function (id) {
		return new javaRoot.$java.$util.$TimeZone();
	}
});
