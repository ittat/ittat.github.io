js2me.createClass({
	superClass: 'javaRoot.$java.$lang.$Exception',
	name: '$MIDletStateChangeException',
	package: 'javaRoot.$javax.$microedition.$midlet'
});
