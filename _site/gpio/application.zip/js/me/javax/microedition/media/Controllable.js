js2me.createInterface({
	package: 'javaRoot.$javax.$microedition.$media',
	name: '$Controllable'
});

