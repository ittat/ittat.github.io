js2me.createClass({
});
	

