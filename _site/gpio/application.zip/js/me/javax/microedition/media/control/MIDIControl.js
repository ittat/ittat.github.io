js2me.createInterface({
	superClass: 'javaRoot.$javax.$microedition.$media.$Control'
});

