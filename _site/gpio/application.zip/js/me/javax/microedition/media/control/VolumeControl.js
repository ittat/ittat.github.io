js2me.createInterface({
	superClass: 'javaRoot.$javax.$microedition.$media.$Control',
	package: 'javaRoot.$javax.$microedition.$media.$control',
	name: '$VolumeControl'
});

