js2me.createClass({
	name: '$HttpConnection',
	package: 'javaRoot.$javax.$microedition.$io'
});
	

