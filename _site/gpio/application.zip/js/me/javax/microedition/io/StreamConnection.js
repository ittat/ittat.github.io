js2me.createInterface({
	interfaces: ['javaRoot.$javax.$microedition.$io.$InputConnection', 'javaRoot.$javax.$microedition.$io.$OutputConnection']
});

