js2me.createInterface({
	package: 'javaRoot.$javax.$microedition.$io',
	name: '$Connection'
});

