js2me.createInterface({
	superClass: 'javaRoot.$javax.$microedition.$io.$Connection',
	package: 'javaRoot.$javax.$microedition.$io',
	name: '$InputConnection'
});

