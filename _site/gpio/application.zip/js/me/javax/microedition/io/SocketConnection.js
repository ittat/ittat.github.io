js2me.createClass({
});
