js2me.createClass({
	superClass: 'javaRoot.$java.$io.$IOException',
	name: '$ConnectionNotFoundException',
	package: 'javaRoot.$javax.$microedition.$io'
});
	

