js2me.createClass({
	/*
	 * public ChoiceGroup(String label, int choiceType)
	 */
	_init$Ljava_lang_String_I_Ljava_lang_String__Ljavax_microedition_lcdui_Image_$V: function (label, type, strings, images) {
		//TODO
	},
	_init$Ljava_lang_String_I$V: function () {
	},
	$append$Ljava_lang_String_Ljavax_microedition_lcdui_Image_$I: function () {
	},
	/*
	 * public void setSelectedIndex(int elementNum, boolean selected)
	 */
	$setSelectedIndex$IZ$V: function (index) {
		//TODO
		/*if (index < 0 || index >= this.items.length) {
			throw new javaRoot.$java.$lang.$IndexOutOfBoundsException();
		}
		this.selectedItem = index;*/
	},
	superClass: 'javaRoot.$javax.$microedition.$lcdui.$Item'
});
