js2me.createClass({
	name: '$AlertType',
	package: 'javaRoot.$javax.$microedition.$lcdui'
});
	

