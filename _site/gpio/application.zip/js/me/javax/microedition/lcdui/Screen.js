js2me.createClass({
	/*
	 * 
	 */
	$setTicker$Ljavax_microedition_lcdui_Ticker_$V: function () {
		//TODO
	},
	superClass: 'javaRoot.$javax.$microedition.$lcdui.$Displayable'
});
