js2me.createClass({
	/*
	 * public Ticker(String str)
	 */
	_init$Ljava_lang_String_$V: function () {
		//TODO
	}
});
