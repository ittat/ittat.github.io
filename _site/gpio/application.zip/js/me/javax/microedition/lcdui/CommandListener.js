js2me.createInterface({
});
	

