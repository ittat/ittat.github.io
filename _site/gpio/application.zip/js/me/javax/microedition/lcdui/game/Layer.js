js2me.createClass({
	x: 0,
	y: 0,
	/*
	 * public void setPosition(int x, int y)
	 */
	$setPosition$II$V: function (x, y) {
		this.x = x;
		this.y = y;
	}
});

