js2me.createClass({
	/*
	 * 
	 */
	$getProperties$$Ljava_util_Hashtable_: function () {
		return new javaRoot.$java.$util.$Hashtable();
	},
	require: ['javaRoot.$java.$util.$Hashtable']
});
