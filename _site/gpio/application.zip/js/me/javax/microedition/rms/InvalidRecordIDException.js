js2me.createClass({
	superClass: 'javaRoot.$javax.$microedition.$rms.$RecordStoreException',
	package: 'javaRoot.$javax.$microedition.$rms',
	name: '$InvalidRecordIDException'
});
