js2me.createClass({
	superClass: 'javaRoot.$javax.$microedition.$rms.$RecordStoreException'
});

