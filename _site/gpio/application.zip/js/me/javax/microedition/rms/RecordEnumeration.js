js2me.createInterface({
	package: 'javaRoot.$javax.$microedition.$rms',
	name: '$RecordEnumeration'
});
