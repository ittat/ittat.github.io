js2me.createInterface({
	superClass: 'javaRoot.$javax.$microedition.$io.$Connection',
	package: 'javaRoot.$javax.$wireless.$messaging',
	name: '$MessageConnection'
});

