js2me.createInterface({
	superClass: 'javaRoot.$javax.$wireless.$messaging.$Message',
	package: 'javaRoot.$javax.$wireless.$messaging',
	name: '$TextMessage'
});

