Please see also: https://github.com/club-wot/WebGPIO

## use settings

 1. setup

> The polyfills has been included into `./Js/`.
> So, it unnecessary the following procedure.

~~# settings~~    
~~npm i -g bower~~    

~~# polyfill install~~    
~~bower install~~    


 2. deployment to chirimen

 3. enjoy button example

## How to construct circuit

Japanese

http://fabble.cc/chirimenedu/chirimenpushbutton
